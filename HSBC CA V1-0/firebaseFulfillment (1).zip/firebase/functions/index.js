'use strict';
/**
 * Cloud Functions & Dialogflow helper setup:
 */
const functions = require('firebase-functions'); // Cloud Functions for Firebase library
const { WebhookClient } = require('dialogflow-fulfillment'); // 

/**
 * SBRA's Pepper Chat fulfillment library:
 */
const { BackgroundImage, BasicCard, BasicText, CarouselImage, Carousel, CarouselImageNoTitle, CarouselNoTitles, 
FullScreenImage, Icon, Icons, Style, TextBubble, TextBubbles, TriggerIntent, Video, Website, PepperResponse, 
toTitleCase, randomlyChoose } = require('pepper-chat-dialogflow');

/**
  * MAIN_MENU MODULE - initialization
  **/
const VALID_STORES_LIST = ['pepper_10002'];

/**
 * WEATHER MODULE - initialization & configuration:
 */
// Load Javascript utility helper libraries: ramda, lodash, & moment
const { path, pluck, mean, compose, map, forEach, addIndex, replace } = require('ramda');
const R = require('ramda');
const { capitalize, toLower, isEmpty } = require('lodash');
const moment = require('moment');

// Load Javascript API requests helper libraries: request & restful.js
const request = require('request');
const restful = require('restful.js');
const { requestBackend } = restful;

// Initialize weather API for requests
const WEATHER_API = restful.default('http://api.worldweatheronline.com', requestBackend(request));  

// Weather Variable Info:
const WEATHER_API_KEY = '41ba62a4d6b34d7599b170527180111'; // https://developer.worldweatheronline.com/my/analytics.aspx?key_id=183570 --> 3 day forecast
const WEATHER_DEFAULT_CITY = '';
const WEATHER_DEFAULT_MSG = "I don't know the weather right now. \\pau=200\\ I'm not allowed to go outside anyways. " +
    "\\pau=800\\ What else would you like to do? || I don't know the weather right now."; 
const WEATHER_FOLLOWUP_MSG = "\\pau=600\\ What else would you like to talk about?";
const WEATHER_FALLBACK_MSG = "I don't know the weather right now, but I always think {city} is a charming place. ";
const WEATHER_FALLBACK_MSG_BUILDER = replace(/\{city\}/g, R.__, `${WEATHER_FALLBACK_MSG} ${WEATHER_FOLLOWUP_MSG} || ${WEATHER_FALLBACK_MSG}`);

/**
 * YELP MODULE - initialization & configuration:
 */
const YELP_API_KEY = 'XHLHzJrEGI7gOsDCzZUNlE_zC-uuzXlGSECB1Zhi2aPZVscjGIS1yE4wQjfZUSferRSbM7EEYTXD6LzlAQkNLEmdJrglltZN2kUIuxGv8ZUyenW1rw98ecTTQFR6WnYx';
const GOOGLE_STATIC_MAPS_KEY = 'AIzaSyBLOntrRQF_FGbo0whydZjwfPHuZ8PPG1A';
const GEOCODER_KEY = 'AIzaSyC-CVWd0AmL_BderjqHSHSLHwsn2NzbW2U';
const yelp = require('yelp-fusion');
const yelp_client = yelp.client(YELP_API_KEY);

/**
 * EMAIL MODULE - initialization & configuration:
 */
const nodemailer = require('nodemailer');

/**
 * SMS (TEXT MESSAGE) MODULE - initialization & configuration:
 */
// Twilio SMS Messaging Service - Create a Twilio account here: www.twilio.com.
const TWILIO_ACCOUNT_SID = 'AC51642a2b3648e935036866f24063add3'; // ← Insert your Twilio Account SID here, e.g. 'A3kj51642a2b3648e935036866f24063add3';
const TWILIO_AUTH_TOKEN = '5b46a85ae92a6198a5aff43f1463fbb0'; // <-- Insert your Twilio Auth Token here, e.g.'5b46asdfda82a6198a5aff43f1463fbb0';
const TWILIO_CLIENT = require('twilio')(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN);
const TWILIO_PHONE_NUMBER = '+14159805622'; // <-- Insert your Twilio here, e.g. '+14159805622'
// phone number validation
const PNF = require('google-libphonenumber').PhoneNumberFormat;
const phoneUtil = require('google-libphonenumber').PhoneNumberUtil.getInstance();
const VALID_COUNTRY_CODE_LIST = ['us', 'uk', 'fr'];

/**
 * Deploy webhook by exporting the function to Google Cloud Functions:
 */
exports.dialogflowFirebaseFulfillment = functions.https.onRequest((request, response) => {
  console.log('Dialogflow Request headers: ' + JSON.stringify(request.headers));
  console.log('Dialogflow Request body: ' + JSON.stringify(request.body));
  if (request.body.result) {
    processV1Request(request, response);
  } else if (request.body.queryResult) {
    processV2Request(request, response);
  } else {
    console.log('Invalid Request');
    return response.status(400).end('Invalid Webhook Request (expecting v1 or v2 webhook request)');
  }
});

function processV2Request(request, response) {
  console.log("Invalid request. This webhook is not configured to accept V2 requests.");
  let msg = "I'm sorry. I'm not configured to use version 2 of Dialogflow";
  response.json({speech: msg, displayText: msg});
}

function processV1Request(request, response) {
    // Setup for all V1 requests to return a V1 response
    let agent = new WebhookClient({request: request, response: response});
    let action = agent.action; // https://dialogflow.com/docs/actions-and-parameters
    let contexts = agent.contexts; // https://dialogflow.com/docs/contexts

    // Setup parameter variables
    let parameters = agent.parameters; // https://dialogflow.com/docs/actions-and-parameters    
    let localContext, local = (localContext=contexts.filter(context => context.name == "local")[0]) ? localContext.parameters || {} : {}; // Local context stores Pepper Chat CMS parameters
    let initContext, init = (initContext=contexts.filter(context => context.name == "init")[0]) ? initContext.parameters || {} : {}; // Init context stores init1234 Chatbot-wide parameters (used for SmallTalk intents)
    console.log("Local parameters (from Pepper Chat CMS): ", JSON.stringify(local));
    console.log("Init parameters (from Welcome Intent): ", JSON.stringify(init));
    console.log("Current intent's parameters: ", parameters);

    // Specify the above handlers in an action handler object
    const actionHandlers = {
        'main_menu': mainMenuHandler,
        'weather': weatherHandler,
        'send_email': emailHandler,
        'send_text': textHandler,
        'yelp.search': localBusinessHandler,
        'yelp.search.business_selected.map_selected': localBusinessHandler,
        'yelp.search.business_selected.more_info': localBusinessHandler,
        'yelp.search.business_selected': localBusinessHandler,
    };   
    actionHandlers[action]();
  
     /***************************************************************************************************************************************************
      * MAIN MENU MODULE
      **************************************************************************************************************************************************/
    function mainMenuHandler() {
        /**
          * This function allows: 
          * First: To replace the Custom payload Response of the intent "BAnk.Intro" and create the main menu
          * Second: To create a Output Context so that we can customize each solution implemented on Pepper according to their store location. 
          **/

        var iconArray =  [  {   "iconUrl": "https://pepperstorageprod.blob.core.windows.net/pepperdrive/150b1263-42d6-492c-a690-bda7eb3a9b9672f41903-2fba-4620-bc55-0911e5b42c2c.png",
                                "value": "Products",
                                "speak": "Apply for a credit card, or a new mortgage. So many options!"
                            },
                            {   "iconUrl": "https://pepperstorageprod.blob.core.windows.net/pepperdrive/150b1263-42d6-492c-a690-bda7eb3a9b96182cfa5a-3730-438c-b215-abd61ac0db1a.png",
                                "value": "Ways to bank",
                                "speak": ""
                            },
                            {   "iconUrl": "https://pepperstorageprod.blob.core.windows.net/pepperdrive/150b1263-42d6-492c-a690-bda7eb3a9b960f6fec4b-600f-431d-b71b-508cf09784b6.png",
                                "value": "Questions",
                                "speak": "Ask me a question"
                            },
                            {   "iconUrl": "https://pepperstorageprod.blob.core.windows.net/pepperdrive/150b1263-42d6-492c-a690-bda7eb3a9b96440d671d-4000-41b6-9507-65312b9a8afb.png",
                                "value": "Talk to a Banker",
                                "speak": "Talk to a Banker"
                            },
                            {   "iconUrl": "https://pepperstorageprod.blob.core.windows.net/pepperdrive/150b1263-42d6-492c-a690-bda7eb3a9b96fadb6f55-303b-4f5b-8762-56b1b31370f8.png",
                                "value": "Have Fun",
                                "speak": "Have fun!"
                            }  ];
        iconArray = iconArray.map(iconObj => { let { iconUrl, value, speak } = iconObj; return new Icon(iconUrl, value, speak);});
        let mainSpeech = "How may I help you? You can select one of these options, or just ask me a question";
        let titleText = "Tap one of the icons below";
        let icons = new Icons(mainSpeech, titleText, iconArray);
        icons.setStyle( {  backgroundColor: "#ffffff" } );

        let responseToPepper = new PepperResponse(icons);

        //Create a context Output that correspond to the store id which will inhibit some intent according to the store_id adding in local parameter on the chatbot
        let nameContextOut = ("store_id" in local) && VALID_STORES_LIST.includes(local.store_id.toLowerCase().trim()) ? local.store_id.toLowerCase().trim() : "default";  
        nameContextOut = (nameContextOut === 'default') && ('STORE_ID' in local) && VALID_STORES_LIST.includes(local.STORE_ID.toLowerCase().trim()) ? local.STORE_ID.toLowerCase().trim() : "default";
        responseToPepper.setContext({ name: nameContextOut, lifespan: 999 });
    console.log("store_id output context:", nameContextOut);
        responseToPepper.send(response); // <-- send() takes the webhook response object as a parameter  

}

    // EMAIL FUNCTIONALITY
    function emailHandler() {

        /** FROM EMAIL MESSAGE INFO: **/
        const PEPPER_EMAIL_ADDRESS = 'hsbc.pepper@gmail.com';
        const PEPPER_EMAIL_PASSWORD = '1stHumanoidRobotBanker';
        const EMAIL_HEADER = `Pepper the HSBC Robot <${PEPPER_EMAIL_ADDRESS}>`;        

        // Demo mode
        let demo_email_list = ['fanny.benoist@softbankrobotics.com', 'daniel.schofield@softbankrobotics.com', 'shyaan.khan@softbankrobotics.com'];
        let demo_mode = ((local) && ("demo" in local) && (['true','yes','y'].includes(local.demo.toString().toLowerCase()))) ? true : false;
        demo_mode = ((!demo_mode) && ("DEMO" in local) && (['true','yes','y'].includes(local.DEMO.toString().toLowerCase()))) ? true : false;

        // Parameters
        let {  emailType, anyName : name = "Human", emailRecipient, appLink_iOS, appLink_Android, productLink, productName  } = parameters;

        // Determine recipients
        let regex_valid_emails = /([a-zA-Z0-9_\-\.\+]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)/g;
        let pepper_chat_cms_email_list = "email_list" in local ? (local.email_list.match(regex_valid_emails) || []) : [];
        pepper_chat_cms_email_list = ((pepper_chat_cms_email_list.length === 0) && "EMAIL_LIST" in local) ? (local.EMAIL_LIST.match(regex_valid_emails) || []) : pepper_chat_cms_email_list;
        let emailRecipients = demo_mode ? demo_email_list : pepper_chat_cms_email_list;
        emailRecipient = emailRecipient ? emailRecipient.match(regex_valid_emails) : undefined;
        console.log(`emailRecipient(s): ${emailRecipient || emailRecipients}`);

        // function that defines and initialzies email template collection
        let emailTemplateTypes = {
          general : {
                'subject': 'A new appointment has been requested',
                'to': emailRecipients,
                'notification_message': `Hello HSBC Team, I have identified a person named ${name}, that would like to speak with you. Thanks, Pepper`,
                'notification_html': `Hello HSBC Team, <br><br> I have identified a person named <b>${name}, </b> who would like to speak with you. <br><br>Thanks,<br> Pepper`,
                'user_response': name !== "Human" ? `Thanks, ${name}. I\'ve notified the branch management of your request to speak to an associate. Someone will be with you shortly. While you wait, is there anything else I can help you with?` : 'I\'ve notified the branch management of your request to speak to an associate. Someone will be with you shortly. While you wait, is there anything else I can help you with?'
            },
          jade: {
                'subject': 'A Jade member would like to speak to you',
                'to': emailRecipients,
                'notification_message': 'Hello HSBC Team, A Jade member has entered the branch, and would like to speak with you. Thanks, Pepper',
                'notification_html': 'Hello HSBC Team, <br><br> I have identified a Jade member who would like to speak with you. <br><br>Thanks,<br> Pepper',
                'user_response': "Welcome, Jade Member. \\pau=600\\ It's great to see you here! I'm notifying one of our bankers, and they'll be here soon. \\pau=1200\\ May I help you with anything else in the meantime? You can say 'help' or ask me a question. I can also dance or tell a joke. || Welcome, Jade Member. It's great to see you here! I'm notifying one of our bankers, and they'll be here soon. May I help you with anything else in the meantime? You can say 'help' or ask me a question. I can also dance or tell a joke."
            },
          app_link: {
                'subject': 'Here\'s your download link for the HSBC mobile app',
                'to': emailRecipient,
                'notification_message': `Welcome to the HSBC Mobile Banking App! As requested, here is the link to download the app to your mobile phone: -${appLink_iOS} on iOS, -${appLink_Android} Thanks, Pepper`,
                'notification_html': `Hello, <br><br> Welcome to the HSBC Mobile Banking App! As requested, here is the link to download the app to your mobile phone: <br> - <a href="${appLink_iOS}">Mobile App on iOS</a> <br> - <a href="${appLink_Android}">Mobile App on Android</a> <br><br>Thanks,<br> Pepper`,
                'user_response': `I've sent you the app download link.|| I've sent the download link to: ${emailRecipient}.`
            },
          product_link: {
                'subject': 'Here\'s your link for applying on the HSBC website',
                'to': emailRecipient,
                'notification_message': `Thank you for your interest in applying for an ${productName}! As requested, here is the link to apply online: ${productLink}` + `Best, Pepper`,
                'notification_html': `Hello, <br><br> Thank you for your interest in applying for an ${productName}! As requested, here is <a href="${productLink}"> the link </a>to apply online.` + `<br> <br> Best, <br> Pepper `,
                'user_response': `I've sent you the online application link. Can I help you with anything else? || I've sent the online application link to: ${emailRecipient}. Can I help you with anything else?`
            },
          moreInfo_link: {
                'subject': 'Here\'s your link for getting more information on the HSBC website',
                'to': emailRecipient,
                'notification_message': `Thank you for your interest in HSBC ${productName}! As requested, here is the link to get more information online: ${productLink}` + `Best, Pepper`,
                'notification_html': `Hello, <br><br> Thank you for your interest in HSBC ${productName}! As requested, here is <a href="${productLink}">the link</a> to get more information online.`+ `<br> <br> Best, <br> Pepper `,
                'user_response': `I've sent you the link to get more information about ${productName}. Can I help you with anything else? || I've sent the online application link to: ${emailRecipient}. Can I help you with anything else?`
            }  };

          if (emailTemplateTypes[emailType] === undefined) {
                fallbackResponse('emailExecution', 'Email Type does not exist for this email collection');
          } else if (['app_link','product_link', 'moreInfo_link'].includes(emailType) && !emailRecipient) {
                fallbackResponse('emailInputValidation', 'Your email address is not valid. Please make sure it is in the correct format. || Your email address is not valid. Please make sure it is in the correct format: yourname@topleveldomain.com ');
          } else {
            // Setup general email data with unicode symbols
            let emailPayload = {  from:     EMAIL_HEADER, // sender address
                                  to:       emailRecipient || emailRecipients, // contact list
                                  subject:  emailTemplateTypes[emailType].subject, // Subject line
                                  text:     emailTemplateTypes[emailType].notification_message, // plain text body
                                  html:     emailTemplateTypes[emailType].notification_html  }; // html body
            var pepper_user_msg = emailTemplateTypes[emailType].user_response;
            // Call the general function to actually send the email
            sendEmail(emailPayload, pepper_user_msg);
          }

        // Define the main email helper function that sends email through nodemailer
        function sendEmail(message_payload, follow_up_msg) {
            var transporter = nodemailer.createTransport( {  service: 'gmail',
                                                             auth: {  user: PEPPER_EMAIL_ADDRESS,
                                                                      pass: PEPPER_EMAIL_PASSWORD  }  });
            const callback = (error, info) => {
                console.log(`sendMail sendMail was ${error ? "un" : ""}successful`);
                if (error) {
                    fallbackResponse('emailExecution', error);
                } else {
                    new PepperResponse(follow_up_msg).send(response);
                }
            };
            transporter.sendMail(message_payload, callback);
        }

        // Trigger if email execution has any errors
        function fallbackResponse(type, message) {
          console.log(`Send email failure type: ${type} | Fallback message: ${message}`);
          let fallback_message = new BackgroundImage(message, "https://pepperstorageprod.blob.core.windows.net/pepperdrive/bac93eda-99a5-4ad3-b620-7ac7885a421579e892b7-f1f5-4cb0-9b63-095591dfcd8d.png");
          switch (type) {
           case 'emailExecution': 
              let trigger_intent = new TriggerIntent("Main Menu");
              (new PepperResponse(fallback_message, trigger_intent)).send(response);
              break;
           case 'emailInputValidation':
               let new_contexts = contexts.map(  context => {
                   switch (context.name) {
                     case "additional_info":
                     case "email_address": 
                       context.lifespan = 0; // Reset these back to 0
                       break;
                     case "local":
                     case "init":
                       break; // Don't modify local or init
                     default:
                       context.lifespan = 1;
                   }
                   return context;
                 });
               let pepperResponse = new PepperResponse(fallback_message);
               pepperResponse.setContext(new_contexts);
               pepperResponse.send(response);
               break;
        }
      }
    }

    /******************************************************************************************************************
     * TEXT MODULE:                                                                                                   *
     ******************************************************************************************************************/
  function textHandler() {
        const { textType, appLink_iOS, appLink_Android, productLink, phoneNumber, productName } = parameters;
        let number = 0;
        let formattedNumber = 0;
        let countryCode = local.country_code && VALID_COUNTRY_CODE_LIST.includes(local.country_code.toLowerCase()) ? local.country_code : "us";

        //Create template for each scenerio whether the webhook has been called from the Product intent or from the Mobile Link or from getting more info
        let textTemplateCollection = {
        'app_link': {       body: `Pepper: Welcome to the HSBC Mobile Banking App! As requested, here is the link to download the app to your mobile phone: ${appLink_iOS} for iOS & ${appLink_Android} for Android`,
                            user_response: `You should have just received a text from me with the download info! Can I help you with anything else?`,
                            triggeredIntent: 'text app link',
                            contextOutput: 'ask_app_link_method'   },
        'product_link': {   body: `Pepper: Thank you for your interest in applying for an ${productName}! As requested, here is the link to apply online:  ${productLink}`,
                            user_response: `You should have just received a text from me with the account info! Can I help you with anything else?`,
                            triggeredIntent: 'Product Link Via SMS',
                            contextOutput: 'ask_product_link_method' },
        'moreInfo_link': {   body: `Pepper: Thank you for your interest in HSBC ${productName}! As requested, here is the link to get more information online: ${productLink}`,
                            user_response: `You should have just received a text from me! Can I help you with anything else?`,
                            triggeredIntent: 'More Info Link Via SMS',
                            contextOutput: 'ask_waysToBank_method' }
        };

        //Verify phone number
        try {
          number = phoneUtil.parseAndKeepRawInput(phoneNumber, countryCode);
          } catch (err) {
            let responseText = new BasicText("Oups! I didn't recognize that as a valid phone number. If you have an international phone number, please make sure to enter the country code.|| Oups! I didn't recognize that as a valid phone number. If you have an international phone number, please make sure to enter the country code.");
            let returnToIntent = new TriggerIntent(textTemplateCollection[textType].triggeredIntent);
            let responseToPepper = new PepperResponse(responseText, returnToIntent);
            responseToPepper.setContext({ name: textTemplateCollection[textType].contextOutput, lifespan: 1 });
            responseToPepper.send(response);  }

        if (phoneUtil.isValidNumber(number) && phoneUtil.isPossibleNumber(number)) {
            formattedNumber = phoneUtil.format(number, PNF.E164);
            console.log(`Phone number to send the message to: ${phoneNumber}`);
            console.log('formatted number ' + formattedNumber);
            TWILIO_CLIENT.messages.create({
                        to: formattedNumber,
                        from: TWILIO_PHONE_NUMBER,
                        body: textTemplateCollection[textType].body})
              .then(message => {
                  console.log("Successfully sent message: ", message.sid);
                  }, err => {
                console.log("Error trying to send Twilio text message", err); });  

              let responseText = new BasicText(textTemplateCollection[textType].user_response);
              let responseToPepper = new PepperResponse(responseText);
              responseToPepper.send(response); // <-- send() takes the webhook response object as a parameter 

          } else {
                let responseText = new BasicText("Oups! I didn't recognize that as a valid phone number. If you have an international phone number, please make sure to enter the country code.|| Oups! I didn't recognize that as a valid phone number. If you have an international phone number, please make sure to enter the country code.");
                let returnToIntent = new TriggerIntent(textTemplateCollection[textType].triggeredIntent);
                let responseToPepper = new PepperResponse(responseText, returnToIntent);
                responseToPepper.setContext({ name: 'ask_app_link_method', lifespan: 1 });
                responseToPepper.send(response); }

   }

     /******************************************************************************************************************
     * WEATHER MODULE:                                                                                                 *
     ******************************************************************************************************************/
    function weatherHandler() {
    /**
     * This function is specific to the data model returned by the World Weather Online 3-day forecast API. The data 
     * model features weather descriptions in increments of 3 hours, starting at midnight (AM) of the current day. */
        let { geoCity : city, date, timePeriod, originalDate = 'today', originalTimePeriod } = parameters;
        // Check to see if the user provided a city; otherwise check if it was set in the CMS; if no city is specified, use the default city
        city = city.length !== 0 ? city : local.city || local.CITY || WEATHER_DEFAULT_CITY;
        date = date.length !== 0 ? date : new Date().toISOString().slice(0, 10);
        let weather_fallback_msg = WEATHER_FALLBACK_MSG_BUILDER(city);
        const weatherRequestPath = `premium/v1/weather.ashx?format=json&num_of_days=1&q=${encodeURIComponent(city)}&key=${WEATHER_API_KEY}&date=${date}`;
        WEATHER_API.custom(weatherRequestPath).get().then( api_response => {
            let timeContext = 'present', currentConditions, weatherCode;
            if (date && moment() <= moment(date)) {
               timeContext = 'future';
            } else if (date && timePeriod) {
                const {    startTime = { hours: 0 }    } = timePeriod; // If the startTime has been provided via timePeriod, use that; otherwise use 0
                if (moment() <= moment(date).add(moment(startTime).hours(), 'hours')) {
                    timeContext = 'future';
                }
            }
            const response_body = api_response.body(false);
            const forecast = path(['data', 'weather', 0], response_body);
            const location = path(['data', 'request', 0], response_body);
            const hourly = path(['hourly'], forecast);

            // Determine weather code
            if (timeContext === 'present') {
                const conditions = path(['data', 'current_condition', 0], response_body);
                currentConditions = path(['weatherDesc', 0, 'value'], conditions);
                weatherCode = conditions.weatherCode; 
            } else {
                const { startTime } = timePeriod;
                const timePeriodHour = moment(startTime).hours() * 100;
                let desiredHour;
                addIndex(forEach)((hour, index) => {
                    try {
                        let startRange = parseInt(hour.time);
                        let endRange = parseInt(hourly[index + 1].time);
                        if (startRange <= timePeriodHour && timePeriodHour <= endRange) {
                            desiredHour = hour;
                        }
                    } catch (e) {
                        if (!desiredHour) desiredHour = hour;
                    }
                })(hourly);
                currentConditions = path(['weatherDesc', 0, 'value'], desiredHour);
                weatherCode = desiredHour.weatherCode;
            }
            const formatedDate = moment(forecast.date).format('MMMM Do YYYY');
            const { mintempC, maxtempC } = forecast;
            const sentenceTense = timeContext === 'future' ? 'there will be' : "it's";
            const defaultSafeDate = (originalDate) => !isEmpty(originalDate) ? originalDate : 'Today'; // Return of value is implicit in 1-line arrow functions (ES6)
            const safeOriginalDate = compose(capitalize, defaultSafeDate)(originalDate); 
            originalTimePeriod = !originalTimePeriod ? "" : originalTimePeriod;
            let simpleText = `${safeOriginalDate} ${originalTimePeriod}, ${sentenceTense} ${toLower(currentConditions)} conditions.`.replace(/\s+/g, ' ');
            simpleText += ` You can expect a high of ${maxtempC}°C and a low of ${mintempC}°C. \\pau=700\\ You can ask me the weather for another city or just say Menu to go back to the main menu?`;
            let defaultMessage = simpleText + ` || You can expect a high of ${maxtempC}°C and a low of ${mintempC}°C.`;
            const chanceOfRain = compose(mean, pluck('chanceofrain'));
            const chance = chanceOfRain(hourly);
            let title = `Weather in ${city || deviceCity}`;
            const text = `${formatedDate}, High - ${maxtempC}, Low - ${mintempC}. chance of rain - ${Math.round(chance)}%`;
            const imageUrl = `https://storage.googleapis.com/core-intelligence-module-assets/weather/${weatherCode}.png`;
            title = simpleText + " || " + title;
            new PepperResponse(new BasicCard(title, imageUrl)).send(response)   
        })
        .catch(error => {
            console.error(error);
            new PepperResponse(randomlyChoose([weather_fallback_msg, WEATHER_DEFAULT_MSG])).send(response)
        });
    }
  
    /******************************************************************************************************************
    * YELP MODULE:                                                                                                 *
    ******************************************************************************************************************/
    function localBusinessHandler() {
        let DEFAULT_LATITUDE = '40.723402', DEFAULT_LONGITUDE = '-74.006673'; // Fallback to San Francisco
        let localBizHandlers = {
            'yelp.search': () => {
                /* First, define the Yelp API querying function, which will be used below.
                 *
                 * @param <array> searchTerms - an array of the search terms parameters
                 * @param <string> filterBy - enum value (review_count, rating, distance) or else null
                 * @param <number> latitude - values range from -90 - 90
                 * @param <number> longitude - values range from -180 - 180
                 * @return Promise => then => returns Yelp results in the form of a Pepper Chat Carousel object
                 */
                function getYelpRecommendations(searchTerms, filterBy, latitude, longitude){
                  return new Promise(function(resolve, reject) {
                    let message = "", searchRequest = { term: searchTerms, latitude: latitude, longitude: longitude };
                    if (filterBy) {
                        searchRequest.sort_by = filterBy;
                        message = "The best option by " + filterBy + " that I found on Yelp is ";
                    }
                    yelp_client.search(searchRequest).then(yelp_response => {
                        var numResponses = yelp_response.jsonBody.businesses.length;
                        if (numResponses === 0) {
                            throw "No results returned by Yelp API query for the search terms [" + searchTerms + "] " +
                            "for the coordinates (" + latitude + ", " + longitude + " ).";
                        }
                        console.log("Success! Yelp API query returned " + numResponses + " results for the search terms [" + searchTerms +
                            "] for the coordinates (" + latitude + ", " + longitude + " ).");
                        numResponses = numResponses > 9 ? 9 : numResponses;
                        console.log("Displaying the first " + numResponses + " results...");
                        let businessData = [];
                        let businessContextStorageObj = {};
                        const pepperIconUrl = "https://pepperstorageprod.blob.core.windows.net/pepperdrive/bac93eda-99a5-4ad3-b620-7ac7885a42155306449d-7527-4887-b073-9ae1d1ae00a1.png";
                        const locationPepperUrl = latitude + "," + longitude;
                        for (let x = 0; x < numResponses; x++) {
                            const businessRaw = yelp_response.jsonBody.businesses[x];
                            // console.log(businessRaw);
                            let businessCarousel = new CarouselImage(
                                            (x+1) + ") " + businessRaw.name, /* title */
                                            businessRaw.image_url, /* url */
                                            "business " + (x+1)  /* trigger new intent string */   );
                            const locationBusinessUrl = encodeURI(businessRaw.location.address1) + "," + encodeURI(businessRaw.location.city);
                            const contextObj = {"name": businessRaw.name,
                                                "rating": businessRaw.rating,
                                                "phone": businessRaw.phone,
                                                "location": businessRaw.location.address1,
                                                "image_url": businessRaw.image_url,
                                                "is_open": !businessRaw.is_closed,
                                                "id": businessRaw.id,
                                                "distance": Math.round(businessRaw.distance),
                                                "google_map_url": "https://maps.googleapis.com/maps/api/staticmap?markers=icon:"+pepperIconUrl+"%7C"+locationPepperUrl+"&markers=color:red%7C"+locationBusinessUrl+"&size=1280x800&path=color:red|weight:5|"+locationPepperUrl+"|"+locationBusinessUrl+"&key="+GOOGLE_STATIC_MAPS_KEY};
                            businessContextStorageObj["business_"+(x+1)] = contextObj;
                            businessData.push(businessCarousel);
                        }
                        // Store business attribute information as context parameters so subsequent requests won't need to re-query Yelp API
                        var context = {     "name": "yelp_storage",
                                            "lifespan": 6,
                                            "parameters": businessContextStorageObj     };
                        if (message.length > 0) {
                            message += yelp_response.jsonBody.businesses[0].name;
                            message = message + ". \\pau=500\\ Either click or say the number of which option interests you. || " + message + ":";
                        } else 
                            message = "Here is what I found on Yelp. \\pau=500\\ Click or say the number of the option that interests you. || Here is what I found on Yelp:";
                        let carousel = new Carousel(message, businessData);
                        console.log(carousel);
                        let carouselResponse = new PepperResponse(carousel);
                        carouselResponse.setContext(context);
                        resolve(carouselResponse);
                    }).catch(e => {
                        console.log('Error getting Yelp listings: ' + e);
                        reject(e);
                    });
                  });
                }
                
                // Begin Main:
                let search_terms, filter_by, which_city;
                let lat = local.latitude || local.LATITUDE || init.latitude || DEFAULT_LATITUDE;
                let long = local.longitude || local.LONGITUDE || init.longitude || DEFAULT_LONGITUDE;
        console.log("lat:", lat);
                console.log("long:", long);
                // If a repeat query:
                if (parameters.go_back){
                    const original = contexts.filter(context => context.name == "yelp");
                    if (original.length > 0) {
                        search_terms = original[0].parameters.search_term;
                        filter_by = original[0].parameters.filter_by;
                        which_city = original[0].parameters.which_city;
                    }
                // If a new query:    
                } else { 
                    search_terms = parameters.search_term;
                    filter_by = parameters.filter_by;
                    which_city = parameters.which_city;
                }
                search_terms = search_terms ? Array.isArray(search_terms) && search_terms.length > 1 ? search_terms.join(" ") : search_terms.toString() : "restaurants";
                filter_by = filter_by ? filter_by.toString() : null;
                console.log("search terms: ", search_terms);
                console.log("filter by: ", filter_by);
                let yelp_error_message = "Hum. My friend Yelp did not answer my call. Please try again later. In the meantime, is there something else I can help you with? || Hmm. My friend Yelp did not answer my call. Please try again later. In the meantime, is there something else I can help you with?";

                // If a specific city is asked about, grab the coordinates for that city
                if (which_city) {
                    const NodeGeocoder = require('node-geocoder');
                    console.log("Searching for latitude and longitude for " + which_city + " ...");
                    try {
                        let options = {
                            provider: 'google',
                            apiKey: GEOCODER_KEY,
                            httpAdapter: 'https', // Default
                            formatter: null   // 'gpx', 'string', ...
                        };
                        let geocoder = new NodeGeocoder(options);
                        geocoder.geocode(which_city)
                            .then(function(resp) {
                                console.log("Results for " + which_city + " query: " + resp[0]);
                                let {latitude,longitude} = resp[0];
                                getYelpRecommendations(search_terms, filter_by, latitude, longitude).then(carousel => carousel.send(response));
                            })
                            .catch(function(err) {
                                console.log(err);
                            });
                    } catch (err) {console.log("No coordinates could be determined for " + which_city);}
                } else {
                    // For all standard queries
                    getYelpRecommendations(search_terms, filter_by, lat, long).then(carousel => carousel.send(response));
                }
            },
            'yelp.search.business_selected': () => {
                try {
                    console.log("yelp.search.business_selected has been triggered");
                    let yelpContext = contexts.filter(context => context.name == "yelp_storage");
                    let id = parameters.business_id;
                    console.log("business id: ", id);
                    console.log("1st Yelp Storage context: ", yelpContext[0]);
                    let businessData = yelpContext[0].parameters["business_" + id];
                    businessData.prettylocation = businessData.location.replace(/St$/,"Street").replace(/Blvd$/,"Boulevard").replace(/Ave$/,"Avenue").replace(/Cir$/,"Circle").replace(/Dr$/,"Drive");
                    console.log("typeof businessData: " + (typeof businessData));
                    let pause = " \\pau=300\\ ";
                    let spokenMessage = ["I love  \\pau=100\\" + businessData.name + ". They are located not too far from here at  \\pau=50\\ " + businessData.prettylocation + "." + pause,
                                       "I hear " + businessData.name + " is a great business \\pau=400\\. They are located close by at \\pau=50\\ " + businessData.prettylocation + "." + pause,
                                       "Great choice!  \\pau=400\\ " + businessData.name + " \\pau=50\\ is located nearby at \\pau=50\\" + businessData.prettylocation + "." + pause,];
                    let spokenMapFollowUp = "You can click or say the following " + pause +
                    /*" Browse images " + pause +*/ " View Business \\pau=50\\ information " + pause + " Show me a map " + pause + "or say" + pause + "Go back";
                    businessData.message = randomlyChoose(spokenMessage) + spokenMapFollowUp + " || " + businessData.name + " : " + businessData.location;
                    let previouslyVisitedContext = contexts.filter(context => context.name == "yelp_biz_visited");
                    if (previouslyVisitedContext.length > 0) {
                        let orSayGoBack = "Or say \\pau=50\\ Go back \\pau=50\\ to go back to the results. ";
                        businessData.message = "Here are your options again for the business " + businessData.name + ". " + orSayGoBack + " || " + businessData.name + " : " + businessData.location;
                    }   
                    console.log(businessData);
                    console.log("BUILDING RICH CARDS");
                    let yelpBizInfoCard = new CarouselImage(
                        "Information", 
                        "https://pepperstorageprod.blob.core.windows.net/pepperdrive/6263cc44-7fef-49b3-bda7-1dda908ca19b55e59677-801d-48ba-bc36-beb7727cb7f3",
                        "Yelp Business Information");
                    let yelpBizMapCard = new CarouselImage(
                        "Map",
                        "https://pepperstorageprod.blob.core.windows.net/pepperdrive/6263cc44-7fef-49b3-bda7-1dda908ca19b33f76445-34e6-482e-a7ec-08c89956c84f",
                        "Map this location");
                    let yelpMenuCardsArray = [yelpBizInfoCard, yelpBizMapCard];
                    let yelpBizMenuCarousel = new Carousel(businessData.message, yelpMenuCardsArray);
                    let yelpBizMenuParameters = {  business_info: { name: businessData.name,
                                                                    location: businessData.location,
                                                                    image_url: businessData.google_map_url,
                                                                    distance: businessData.distance,
                                                                    phone: businessData.phone,
                                                                    is_open: businessData.is_open,
                                                                    rating: businessData.rating,
                                                                    id: id    }   };
                    let carouselResponse = new PepperResponse(yelpBizMenuCarousel);
                    carouselResponse.setContext({ name:"yelp_business_selected",lifespan:2,parameters:yelpBizMenuParameters });                    
                    carouselResponse.send(response);
                } catch(err){
                    console.log(err);
                    let errorResponse = new PepperResponse("What else would you like to talk about?");
                    errorResponse.send(response);
                }
            },
            'yelp.search.business_selected.map_selected': () => {
                let mapContext = request.body.result.contexts.filter(context => context.name == "yelp_business_selected");
                let mapped_business = mapContext[0].parameters.business_info;
                console.log("Map Parameters: ", JSON.stringify(mapped_business));
                let mapSpeech = "Here is a general sense of how to get to " + mapped_business.name + " \\pau=10000\\ || :)";
                let map = new FullScreenImage(mapSpeech, mapped_business.image_url);
                let returnToBizMenu = new TriggerIntent("Business " + mapped_business.id);
                let followUpQuestion = new BasicText("What else can I help you with?");
                let mapThenReturnToBizMenu = new PepperResponse(map, returnToBizMenu);
                mapThenReturnToBizMenu.setContext({name: "yelp_biz_visited", lifespan: 2, parameters: {visited: true}});
                mapThenReturnToBizMenu.send(response);
            },
            'yelp.search.business_selected.more_info': () => {
                let yelpBizContext = request.body.result.contexts.filter(context => context.name == "yelp_business_selected");
                let business = yelpBizContext[0].parameters.business_info;
                // console.log("Yelp Business Info Selected - Context: ", yelpBizContext[0]);
                // console.log("Yelp Selected Business Info Parameters: ", business);
                let message = "Here is the requested information! \\pau=8000\\ || Name: " + business.name + " | Phone Number: " +
                                business.phone + " |  Address: " + business.location + " | Rating: " + business.rating  +
                                " | Open now: " + (business.rating ? "Yes " : "No") + " | Distance from here:  " + business.distance + "m";
                let returnToBizMenu = new TriggerIntent("Business " + business.id);
                let moreBizInfoResponse = new PepperResponse(message, returnToBizMenu);
                moreBizInfoResponse.setContext({name: "yelp_biz_visited", lifespan: 2, parameters: {visited: true}});
                moreBizInfoResponse.send(response);
            }
        };
        // Execute the correct function, based on actions
        localBizHandlers[action]();
    }
}